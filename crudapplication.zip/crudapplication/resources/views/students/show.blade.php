
@extends('students.layout')
@section('content')

<div class="card" style="margin:20px;">
    <div class="card-header"style="color:red">Students Page</div>
    <div class="card-body">
        <div class="card-body">
            <h5 class="card-title" style="color:red">Name : {{ $students->name }}</h5>
            <p class="card-text" style="color:red">Address : {{ $students->address }}</p>
            <p class="card-text" style="color:red">Mobile : {{ $students->mobile }}</p>
        </div>
        </hr>
    </div>
</div>